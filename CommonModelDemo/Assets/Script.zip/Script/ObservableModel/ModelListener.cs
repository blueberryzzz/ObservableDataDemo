﻿using System;
using System.Collections.Generic;

//通知事件的类型
[Flags]
public enum ModelListenerType
{
    INIT             = 2 << 0,
    UPDATE           = 2 << 1,
    ADD              = 2 << 2,
    REMOVE           = 2 << 3,
    CLEAR            = 2 << 4,

    INSERT           = 2 << 5,

    INIT_AND_UPDATE  = INIT | UPDATE,
}

/// <summary>
/// 数据监听事件的基类
/// </summary>
public abstract class ModelListener
{
    //添加该监听事件时，是否需要根据已有的数据调用一次监听事件
    public bool FullUpdateFirst;
    //事件类型
    public ModelListenerType ListenerType;

    public object Holder;

    public ModelListener(ModelListenerType listenerType, object holder = null, bool fullupdateFirst = false)
    {
        ListenerType = listenerType;
        Holder = holder;
        FullUpdateFirst = fullupdateFirst;
    }

    //根据事件类型进行通知
    public abstract void FireEventForListener(object data);
}

/// <summary>
/// 单数据修改监听事件类
/// </summary>
public class ModelActionListener<T> : ModelListener
{
    public Action<T> ListenerFunc;

    public ModelActionListener(Action<T> listener, ModelListenerType listenerType,object holder = null,bool fullupdateFirst = false):base(listenerType,holder,fullupdateFirst)
    {
        ListenerFunc = listener;
    }

    //通知监听事件
    public override void FireEventForListener(object data)
    {
        if (data != null && ListenerFunc != null)
        {
            ListenerFunc((T)data);
        }
    }
}

//列表数据修改监听
public delegate void ListCallback<T>(List<T> dataList);
public class ModelListListener<T> : ModelListener
{
    
    public ListCallback<T> ListenerFunc;

    public ModelListListener(ListCallback<T> listener, ModelListenerType listenerType, object holder = null, bool fullupdateFirst = false) : base(listenerType, holder, fullupdateFirst)
    {
        ListenerFunc = listener;
    }

    //通知监听事件
    public override void FireEventForListener(object data)
    {
        if (data != null && ListenerFunc != null)
        {
            ListenerFunc((List<T>)data);
        }
    }
}

//列表插入修改监听
public delegate void InsertCallback<T>(List<T> dataList, int index);
public class ListInsertStruct<T>
{
    public List<T> DataList;
    public int Index;

    public ListInsertStruct(List<T> dataList,int index)
    {
        DataList = dataList;
        Index = index;
    }
}
public class ModelInsertListener<T> : ModelListener
{

    public InsertCallback<T> ListenerFunc;

    public ModelInsertListener(InsertCallback<T> listener, ModelListenerType listenerType, object holder = null, bool fullupdateFirst = false) : base(listenerType, holder, fullupdateFirst)
    {
        ListenerFunc = listener;
    }

    //通知监听事件
    public override void FireEventForListener(object data)
    {
        ListInsertStruct<T> insertStruct = data as ListInsertStruct<T>;
        if (insertStruct != null && insertStruct.DataList != null && ListenerFunc != null)
        {
            ListenerFunc(insertStruct.DataList,insertStruct.Index);
        }
    }
}